<?php get_header(); ?>
<!-- Banner -->
<section class="banner inner-page">
    <div class="container">
        <div class="banner-wrap">
            <h1><?php single_cat_title(); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo home_url(); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php single_cat_title(); ?></li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<!-- Start Technology Sections -->

<!-- Start Must Read Sections -->
<section class="blogs col-4-items pt pb">
    <div class="container">
        <div class="blog-posts">
            <div class="blog-main">
                <div class="row">
                    <?php 
                    $counter = 1; // Initialize counter variable
                    if (have_posts()) {
                        while (have_posts()) : the_post(); ?>
                            <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                                <div class="blog-col">
                                    <div class="blog-media">
                                        <a class="number" href="<?php the_permalink(); ?>" title="">
                                            <div class="blog-image-container">
                                                <div class="blog-overlay">
                                                    <div class="blog-text">
                                                        <h3><?php echo $counter . '. '; ?><a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></h3> <!-- Add numbering -->
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php $counter++; // Increment counter ?>
                        <?php endwhile; 
                    } else { ?>
                        <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Must Read Sections -->


<style>
    .pagination {
        text-align: center;
        margin: 20px 0;
    }

    .pagination ul {
        list-style: none;
        padding: 0;
        display: inline-flex;
    }

    .pagination li {
        margin: 0 5px;
    }

    .pagination a, .pagination span {
        display: inline-block;
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 4px;
        color: #333;
        text-decoration: none;
    }

    .pagination a:hover {
        background-color: #f0f0f0;
    }

    .pagination .current {
        background-color: #333;
        color: #fff;
        border: 1px solid #333;
    }

</style>
<?php get_footer(); ?>
