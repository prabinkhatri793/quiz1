<?php get_header();?>


<!-- Start Games Sections -->
<section class="blogs bg-sec pt pb">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="quiz">
                    <div class="ays-quiz-container">
                        <div class="step">
                            <h2 class="title">Play and Win: Join Our Jobs Quiz Challenge!</h2>
                            <p>Think you know a lot about different careers? Put your knowledge to the test with our Jobs Quiz Challenge! From tech to healthcare, education to engineering, see how well you can match professions to their roles. It's fun, fast, and a great way to learn about the world of work. Plus, you could win exciting prizes! Ready to play? Jump in and prove you're a career expert!</p>
                            <a href="http://localhost/quiz1/whats-the-term-for-the-practice-of-working-for-different-companies-on-temporary-assignments/" class="btn">Start Quiz</a>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="col-md-4">
                <div class="">
                    <img src="<?php bloginfo('template_url'); ?>/images/happy-girl-with-laptop-professional-girl-image-png.png" class="img-responsive">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End App Sections -->

<!-- Banner End -->
<section class="about-us">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <?php get_sidebar();?>
            </div>
            <div class="col-md-8">
                <div class="content">
                    <?php while (have_posts()) : the_post(); ?>

                           <?php the_content(); ?>

                       <?php endwhile; ?>
                       <a href="http://localhost/quiz1/about-us/" class="btn" style="background: #00a9a3; color: #fff; font-weight: 700; padding: 10px 20px; border-radius: 12px;">Read More</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Start Banner -->
<!-- Start Games Sections -->
<section class="blogs bg-sec pt pb">
    <div class="container">
        <div class="row">
            <div class="col-md-1">
            </div>
            <div class="col-md-2">
                <div class="">
                    <img src="<?php bloginfo('template_url'); ?>/images/man-design.png" class="img-responsive">
                </div>
            </div>
            <div class="col-md-9">
                <div class="quiz">
                    <div class="ays-quiz-container">
                        <div class="step">
                            <h2 class="title">Play and Win: Join Our Investment Quiz Challenge!</h2>
                            <p>Are you ready to put your investment knowledge to the test? Take our exciting Investment Quiz and stand a chance to win amazing prizes! Whether you’re a seasoned investor or just starting out, this quiz is designed to challenge your financial acumen and reward you for your expertise.</p>
                            <a href="http://localhost/quiz1/what-does-roi-stand-for-in-the-world-of-investment/" class="btn">Start Quiz</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End App Sections -->
<!-- Start Must Read Sections -->
<section class="blogs col-4-items pt pb">
    <div class="container">
        <div class="heading-section d-flex justify-content-between align-items-center">
            <div class="category-name">
                <h3>GWF Quiz </h3>
            </div>
        </div>
        <div class="blog-posts">
            <div class="blog-main">
                <div class="row">
                    <?php 
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 4,
                        'orderby' => 'ID',
                        'order' => 'ASC'
                    );
                    $query = new WP_Query($args);
                    if ($query->have_posts()) {
                        while ($query->have_posts()) : $query->the_post(); ?>
                            <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                                <div class="blog-col">
                                    <div class="blog-media">
                                        <a href="<?php the_permalink(); ?>" title="">
                                            <div class="blog-image-container">
                                                <div class="blog-overlay">
                                                    <div class="blog-text">
                                                        <h3><a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; 
                        wp_reset_postdata();
                    } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Must Read Sections -->
<!-- Start Games Sections -->
<section class="contact-us blogs bg-sec pt pb">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="quiz">
                    <div class="ays-quiz-container">
                        <div class="step">
                            <h2 class="title">Play and Win: Join Our Cryptocurrency Quiz Challenge!</h2>
                            <p>Are you a crypto enthusiast or just curious about the world of digital currencies? Put your knowledge to the test and win exciting prizes in our Cryptocurrency Quiz Challenge! Whether you're a seasoned trader or new to the crypto scene, this quiz is your chance to showcase your skills, learn something new, and possibly walk away with some cool rewards.</p>
                            <a href="http://localhost/quiz1/what-was-the-first-cryptocurrency-ever-created/" class="btn">Start Quiz</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form register">
                    <?php echo do_shortcode('[contact-form-7 id="f2c4bd2" title="Contact Us"]'); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End App Sections -->
<!-- Start Must Read Sections -->
<section class="blogs col-4-items pt pb">
    <div class="container">
        <div class="heading-section d-flex justify-content-between align-items-center">
            <div class="category-name">
                <h3>Popular Questions</h3>
            </div>
        </div>
        <div class="blog-posts">
            <div class="blog-main">
                <div class="row">
                    <?php 
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 8,
                        'meta_key' => 'post_views', // Custom field for view count
                        'orderby' => 'meta_value_num', // Order by view count
                        'order' => 'ASC'
                    );
                    $query = new WP_Query($args);
                    $counter = 1; // Initialize counter variable
                    if ($query->have_posts()) {
                        while ($query->have_posts()) : $query->the_post(); ?>
                            <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                                <div class="blog-col">
                                    <div class="blog-media">
                                        <a  class="number" href="<?php the_permalink(); ?>" title="">
                                            <div class="blog-image-container">
                                                <div class="blog-overlay">
                                                    <div class="blog-text">
                                                        <h3><?php echo $counter . '. '; ?><a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></h3> <!-- Add numbering -->
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php $counter++; // Increment counter ?>
                        <?php endwhile; 
                        wp_reset_postdata();
                    } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Must Read Sections -->

<?php get_footer(); ?>






