<?php get_header();?>


    <!-- Banner -->
	<section class="banner inner-page">
		<div class="container">
			<div class="banner-wrap">
				<h1>Play and Win</span></h1>
				

			</div>
		</div>
	</section>
	
	<div class="pt-5 pb-5">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="blog-details-main">
						<div class="blog-details-content">
						    <div class="quiz">
						    	<?php
								// Inside the WordPress loop in single.php
								if (have_posts()) :
								    while (have_posts()) : the_post(); ?>
								        <div id="timer-display">Time left: 60 seconds</div> <!-- Timer display -->
								        <div id="post-content"> <!-- Wrapper for post content -->
								            <?php the_content(); ?>
								        </div>
								        <!-- Go Back Home button (initially hidden) -->
								        <button id="go-back-home" style="display:none;" onclick="window.location.href='<?php echo home_url(); ?>'">Go Back Home</button>
								    <?php endwhile;
								endif;
								?>


			                </div>
						</div>
					</div>
					
					<!-- End Must Read Sections -->

				</div>
				
				<div class="col-md-4">
					<?php get_sidebar();?>
				</div>
			</div>
		</div>
	</div>
	

    <!-- Location -->

    <style>
        div#exampleModalCenter {
            z-index: 99999 !important;
        }
        .modal-body {
            padding: 0px;
        }
    </style>
<?php get_footer();?>