<?php  
/*
Template Name: Thank You Page
*/
get_header();
?>
    <!-- Slider -->
    <section class="banner slider-alt pt pb" style="background-image: url('<?php bloginfo('template_url'); ?>/images/top-banner.jpg'); background-position: bottom; background-size: cover;">
        <div class="container">
            <div class="banner-wrap slider-wrap-alt">
                <div class="banner2-right">
                    <div class="banner2-form">
                        <h1 style="text-align:center;"><?php the_title();?></h1> 
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Slider End -->
	<div class="thank-you">
		<div class="container">
			<div class="thank-you-wrap">
				Thanks for submitting your response! You can edit this message on the "Results Pages" tab. <br /><qsmvariabletag>CONTACT_ALL</qsmvariabletag> <br /><qsmvariabletag>QUESTIONS_ANSWERS</qsmvariabletag>
			</div>
		</div>
	</div>


 <?php get_footer();?>